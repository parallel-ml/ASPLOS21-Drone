# drone

The folder boot_pi_backup contains a full backup of the drone Pi's SD card

The bash scripts serve the purpose of examining performance of specified PIDs using Linux perf utility

## SLAM
To run SLAM, please downalod a dataset sample, for example http://robotics.ethz.ch/~asl-datasets/ijrr_euroc_mav_dataset/machine_hall/MH_01_easy/MH_01_easy.zip

Extract the datset inside the slam directory

Then run ```docker-compose up -d```
